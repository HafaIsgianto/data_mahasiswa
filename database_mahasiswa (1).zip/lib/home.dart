import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'tambah_data.dart';
import 'edit_data.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => HomeState();
}

class HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Database Firebase'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => TambahData(),
            ),
          );
        },
        child: const Icon(Icons.add),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('mahasiswa').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return Container(
              padding: const EdgeInsets.fromLTRB(5, 10, 5, 5),
              child: Card(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: snapshot.data!.docs.length,
                  itemBuilder: (context, index) {
                    DocumentSnapshot documentSnapshot =
                        snapshot.data!.docs[index];
                    return Column(
                      children: [
                        GestureDetector(
                          child: ListTile(
                            leading: const Icon(Icons.person),
                            title: Text(documentSnapshot['nim']),
                            subtitle: Text(documentSnapshot['nama']),
                            trailing: const Icon(Icons.navigate_next_rounded),
                          ),
                          onTap: () {
                            // BARU: data dibaca ke Map supaya dokumen lama
                            // yang belum punya field kelas tidak error
                            final data =
                                documentSnapshot.data() as Map<String, dynamic>;

                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => EditData(
                                  nim: documentSnapshot["nim"],
                                  nama: documentSnapshot["nama"],
                                  prodi: documentSnapshot["prodi"],
                                  kelas: data['kelas'] ?? '', // BARU
                                ),
                              ),
                            );
                          },
                        ),
                        const Divider(
                          color: Colors.black,
                          indent: 10,
                          endIndent: 10,
                        ),
                      ],
                    );
                  },
                ),
              ),
            );
          } else {
            return const Center(
              child: CircularProgressIndicator(
                backgroundColor: Colors.black,
              ),
            );
          }
        },
      ),
    );
  }
}
