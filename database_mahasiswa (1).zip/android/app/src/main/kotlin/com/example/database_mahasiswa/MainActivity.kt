package com.example.database_mahasiswa

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
